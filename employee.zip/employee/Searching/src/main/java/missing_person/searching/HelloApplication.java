package missing_person.searching;

import javafx.application.Application;
import javafx.application.HostServices;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class HelloApplication extends Application {
    private static HostServices hostServices;

    public static HostServices getHostServicesStatic() {
        return hostServices;
    }

    @Override
    public void start(Stage stage) throws Exception {
        hostServices = getHostServices(); // Set static reference

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 720, 820);
        stage.setTitle("Missing Person Finder");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
