package missing_person.searching;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;

import javax.sound.sampled.*;
import java.io.*;

public class HelloController {

    @FXML private TextField nameField;
    @FXML private TextField ageField;
    @FXML private TextField locationField;
    @FXML private TextField cardNumberField;
    @FXML private TextArea witnessTextArea;
    @FXML private Button startRecordBtn;
    @FXML private Button stopRecordBtn;
    @FXML private Label recordStatusLabel;
    @FXML private MediaView mediaView;

    private ByteArrayOutputStream outStream;
    private TargetDataLine targetDataLine;
    private MediaPlayer mediaPlayer;

    // ------------- Credit Card Tracing -------------
    @FXML
    private void onTraceCard() {
        String cardNumber = cardNumberField.getText();
        if (cardNumber.isEmpty()) {
            showAlert("Card number field is empty.");
            return;
        }

        if (cardNumber.startsWith("1234")) {
            locationField.setText("Dhaka");
            witnessTextArea.setText("Witness: Last seen near Gulshan Park.");
        } else if (cardNumber.startsWith("5678")) {
            locationField.setText("Chittagong");
            witnessTextArea.setText("Witness: Seen at New Market area.");
        } else {
            locationField.setText("Unknown");
            witnessTextArea.setText("No witness information found.");
        }
    }

    // ------------- Load and Play CCTV Video -------------
    @FXML
    private void onPlayVideo() {
        try {
            File file = new File("src/main/resources/missing_person/searching/cctv.mp4");
            if (!file.exists()) {
                showAlert("CCTV video file not found.");
                return;
            }
            Media media = new Media(file.toURI().toString());
            MediaPlayer player = new MediaPlayer(media);
            mediaView.setMediaPlayer(player);
            player.play();
        } catch (Exception e) {
            showAlert("Error playing CCTV video: " + e.getMessage());
        }
    }

    // ------------- Audio Recording -------------
    @FXML
    private void onStartRecording() {
        try {
            AudioFormat format = getAudioFormat();
            DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
            if (!AudioSystem.isLineSupported(info)) {
                showAlert("Microphone not supported.");
                return;
            }

            targetDataLine = (TargetDataLine) AudioSystem.getLine(info);
            targetDataLine.open(format);
            targetDataLine.start();

            outStream = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];

            startRecordBtn.setDisable(true);
            stopRecordBtn.setDisable(false);
            recordStatusLabel.setText("Recording...");

            Thread recordingThread = new Thread(() -> {
                try {
                    while (!Thread.currentThread().isInterrupted()) {
                        int count = targetDataLine.read(buffer, 0, buffer.length);
                        if (count > 0) {
                            outStream.write(buffer, 0, count);
                        }
                    }
                } catch (Exception ex) {
                    Platform.runLater(() -> showAlert("Error during recording: " + ex.getMessage()));
                }
            });
            recordingThread.setDaemon(true);
            recordingThread.start();

        } catch (LineUnavailableException ex) {
            showAlert("Microphone not available.");
        }
    }

    @FXML
    private void onStopRecording() {
        if (targetDataLine != null) {
            targetDataLine.stop();
            targetDataLine.close();

            startRecordBtn.setDisable(false);
            stopRecordBtn.setDisable(true);
            recordStatusLabel.setText("Recording stopped.");

            // Save recording to file
            saveRecordingToFile();
            witnessTextArea.appendText("\n\n[Audio testimony recorded ✅]");
        }
    }

    private void saveRecordingToFile() {
        try {
            File outputFile = new File("witness_recording.wav");
            byte[] audioData = outStream.toByteArray();
            ByteArrayInputStream bais = new ByteArrayInputStream(audioData);
            AudioFormat format = getAudioFormat();
            AudioInputStream audioInputStream = new AudioInputStream(bais, format, audioData.length / format.getFrameSize());
            AudioSystem.write(audioInputStream, AudioFileFormat.Type.WAVE, outputFile);
            audioInputStream.close();
            bais.close();
            System.out.println("Recording saved to: " + outputFile.getAbsolutePath());
        } catch (IOException e) {
            showAlert("Failed to save recording: " + e.getMessage());
        }
    }

    @FXML
    private void onPlayWitnessRecording() {
        try {
            File file = new File("witness_recording.wav");
            if (!file.exists()) {
                showAlert("No recorded witness audio found.");
                return;
            }

            if (mediaPlayer != null) {
                mediaPlayer.stop();
            }
            Media media = new Media(file.toURI().toString());
            mediaPlayer = new MediaPlayer(media);
            mediaPlayer.play();
            showAlert("🎧 Playing recorded witness testimony...");
        } catch (Exception e) {
            showAlert("Error playing witness recording: " + e.getMessage());
        }
    }

    private AudioFormat getAudioFormat() {
        return new AudioFormat(16000, 16, 1, true, true);
    }

    // ------------- Final Report Submission -------------
    @FXML
    private void onSubmitReport() {
        String name = nameField.getText();
        String age = ageField.getText();
        String location = locationField.getText();
        String witnessInfo = witnessTextArea.getText();

        if (name.isEmpty() || age.isEmpty() || location.isEmpty()) {
            showAlert("Please fill in all required fields.");
            return;
        }

        System.out.println("Missing Person Report:");
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Last Known Location: " + location);
        System.out.println("Witness Information: " + witnessInfo);

        showAlert("Report submitted successfully. ✅");
    }

    private void showAlert(String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Info");
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }
}
