module missing_person.searching {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.media;
    requires java.desktop; // ✅ This line fixes the javax.sound.sampled error

    opens missing_person.searching to javafx.fxml;
    exports missing_person.searching;
}
